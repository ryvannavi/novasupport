<div style="padding:30px; animation:fadeUp 0.6s ease both;">
    <div style="max-width:700px; margin:0 auto;">

        <a href="{{ route('tickets.index') }}" class="ajax-link" data-url="{{ route('tickets.index') }}" style="display:inline-flex; align-items:center; gap:6px; font-size:12px; color:#6366f1; text-decoration:none; margin-bottom:20px; font-weight:600; cursor:pointer;" onmouseover="this.style.gap='10px'" onmouseout="this.style.gap='6px'">
            <i class="fa-solid fa-arrow-left"></i> Back to requests
        </a>

        <!-- REST OF YOUR CONTENT HERE -->
        <!-- Copy everything from your current tickets/show.blade.php but REMOVE the <x-app-layout> wrapper -->

    </div>
</div>