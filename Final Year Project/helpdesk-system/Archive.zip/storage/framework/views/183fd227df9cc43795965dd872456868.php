<div style="padding:30px; animation:fadeUp 0.6s ease both;">
    <div style="max-width:700px; margin:0 auto;">

        <a href="<?php echo e(route('tickets.index')); ?>" class="ajax-link" data-url="<?php echo e(route('tickets.index')); ?>" style="display:inline-flex; align-items:center; gap:6px; font-size:12px; color:#6366f1; text-decoration:none; margin-bottom:20px; font-weight:600; cursor:pointer;" onmouseover="this.style.gap='10px'" onmouseout="this.style.gap='6px'">
            <i class="fa-solid fa-arrow-left"></i> Back to requests
        </a>

        <!-- REST OF YOUR CONTENT HERE -->
        <!-- Copy everything from your current tickets/show.blade.php but REMOVE the <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> wrapper -->

    </div>
</div><?php /**PATH /Users/wanli/Desktop/Final Year Project/helpdesk-system/resources/views/tickets/show-content.blade.php ENDPATH**/ ?>