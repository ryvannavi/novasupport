<?php if(request()->has('ajax')): ?>
    <div style="padding:30px; animation:fadeUp 0.6s ease both;">
        <div style="max-width:900px; margin:0 auto;">

            <!-- Header -->
            <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px;">
                <div>
                    <div style="font-size:22px; font-weight:800; color:#0f172a; margin-bottom:4px;">My Support Requests</div>
                    <div style="font-size:12px; color:#64748b;">Track and manage all your support requests</div>
                </div>
                <a href="<?php echo e(route('tickets.create')); ?>" class="btn-nova ajax-nav-link" data-url="<?php echo e(route('tickets.create')); ?>">
                    <span><i class="fa-solid fa-plus"></i> New Request</span>
                </a>
            </div>

            <?php if(session('success')): ?>
                <div style="background:#dcfce7; color:#15803d; padding:12px 16px; border-radius:12px; font-size:12px; margin-bottom:16px; display:flex; align-items:center; gap:8px;">
                    <i class="fa-solid fa-circle-check"></i> <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <!-- Tickets List -->
            <?php if($tickets->count() === 0): ?>
                <div style="background:rgba(255,255,255,0.92); border:1px solid #e8eaf0; border-radius:20px; padding:60px; text-align:center;">
                    <div style="width:60px; height:60px; background:linear-gradient(135deg,#ede9fe,#ddd6fe); border-radius:16px; display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
                        <i class="fa-solid fa-ticket" style="color:#7c3aed; font-size:24px;"></i>
                    </div>
                    <div style="font-size:16px; font-weight:700; color:#0f172a; margin-bottom:6px;">No requests yet</div>
                    <div style="font-size:12px; color:#64748b; margin-bottom:20px;">Submit your first support request and get instant AI-powered help.</div>
                    <a href="<?php echo e(route('tickets.create')); ?>" class="btn-nova ajax-nav-link" data-url="<?php echo e(route('tickets.create')); ?>">
                        <span><i class="fa-solid fa-plus"></i> Submit Request</span>
                    </a>
                </div>
            <?php else: ?>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('tickets.show', $ticket->id)); ?>" class="ajax-link" data-url="<?php echo e(route('tickets.show', $ticket->id)); ?>" style="text-decoration:none; background:rgba(255,255,255,0.92); border:1px solid #eef0f8; border-radius:16px; padding:18px 20px; display:flex; align-items:center; gap:16px; transition:all 0.35s cubic-bezier(0.34,1.56,0.64,1); box-shadow:0 2px 8px rgba(0,0,0,0.03); position:relative; overflow:hidden; animation:fadeUp 0.5s <?php echo e($i * 0.08 + 0.2); ?>s ease both;"
                        onmouseover="this.style.transform='translateX(6px) translateY(-2px)'; this.style.boxShadow='0 12px 32px rgba(99,102,241,0.12)'; this.style.borderColor='#c7d2fe';"
                        onmouseout="this.style.transform=''; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.03)'; this.style.borderColor='#eef0f8';">
                        <div style="width:44px; height:44px; border-radius:12px; background:linear-gradient(135deg,#ede9fe,#ddd6fe); display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                            <i class="fa-solid fa-headset" style="color:#7c3aed; font-size:18px;"></i>
                        </div>
                        <div style="flex:1;">
                            <div style="font-size:13px; font-weight:700; color:#0f172a; margin-bottom:3px;">#SR-00<?php echo e($ticket->id); ?> — <?php echo e($ticket->title); ?></div>
                            <div style="font-size:11px; color:#64748b;"><?php echo e($ticket->created_at->diffForHumans()); ?></div>
                        </div>
                        <?php
                            $statusStyles = [
                                'open' => 'background:#ede9fe; color:#5b21b6;',
                                'in_progress' => 'background:#fef3c7; color:#92400e;',
                                'resolved' => 'background:#d1fae5; color:#065f46;',
                            ];
                            $statusIcons = [
                                'open' => 'fa-circle-dot',
                                'in_progress' => 'fa-spinner',
                                'resolved' => 'fa-circle-check',
                            ];
                        ?>
                        <span style="font-size:10px; font-weight:600; padding:4px 12px; border-radius:99px; <?php echo e($statusStyles[$ticket->status] ?? ''); ?> display:inline-flex; align-items:center; gap:4px;">
                            <i class="fa-solid <?php echo e($statusIcons[$ticket->status] ?? 'fa-circle'); ?>" style="font-size:8px;"></i>
                            <?php echo e(ucfirst(str_replace('_',' ',$ticket->status))); ?>

                        </span>
                        <i class="fa-solid fa-chevron-right" style="color:#94a3b8; font-size:11px;"></i>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php else: ?>
    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div style="padding:30px; animation:fadeUp 0.6s ease both;">
            <div style="max-width:900px; margin:0 auto;">

                <!-- Header -->
                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px;">
                    <div>
                        <div style="font-size:22px; font-weight:800; color:#0f172a; margin-bottom:4px;">My Support Requests</div>
                        <div style="font-size:12px; color:#64748b;">Track and manage all your support requests</div>
                    </div>
                    <a href="<?php echo e(route('tickets.create')); ?>" class="btn-nova ajax-nav-link" data-url="<?php echo e(route('tickets.create')); ?>">
                        <span><i class="fa-solid fa-plus"></i> New Request</span>
                    </a>
                </div>

                <?php if(session('success')): ?>
                    <div style="background:#dcfce7; color:#15803d; padding:12px 16px; border-radius:12px; font-size:12px; margin-bottom:16px; display:flex; align-items:center; gap:8px;">
                        <i class="fa-solid fa-circle-check"></i> <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <!-- Tickets List -->
                <?php if($tickets->count() === 0): ?>
                    <div style="background:rgba(255,255,255,0.92); border:1px solid #e8eaf0; border-radius:20px; padding:60px; text-align:center;">
                        <div style="width:60px; height:60px; background:linear-gradient(135deg,#ede9fe,#ddd6fe); border-radius:16px; display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
                            <i class="fa-solid fa-ticket" style="color:#7c3aed; font-size:24px;"></i>
                        </div>
                        <div style="font-size:16px; font-weight:700; color:#0f172a; margin-bottom:6px;">No requests yet</div>
                        <div style="font-size:12px; color:#64748b; margin-bottom:20px;">Submit your first support request and get instant AI-powered help.</div>
                        <a href="<?php echo e(route('tickets.create')); ?>" class="btn-nova ajax-nav-link" data-url="<?php echo e(route('tickets.create')); ?>">
                            <span><i class="fa-solid fa-plus"></i> Submit Request</span>
                        </a>
                    </div>
                <?php else: ?>
                    <div style="display:flex; flex-direction:column; gap:10px;">
                        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('tickets.show', $ticket->id)); ?>" class="ajax-link" data-url="<?php echo e(route('tickets.show', $ticket->id)); ?>" style="text-decoration:none; background:rgba(255,255,255,0.92); border:1px solid #eef0f8; border-radius:16px; padding:18px 20px; display:flex; align-items:center; gap:16px; transition:all 0.35s cubic-bezier(0.34,1.56,0.64,1); box-shadow:0 2px 8px rgba(0,0,0,0.03); position:relative; overflow:hidden; animation:fadeUp 0.5s <?php echo e($i * 0.08 + 0.2); ?>s ease both;"
                            onmouseover="this.style.transform='translateX(6px) translateY(-2px)'; this.style.boxShadow='0 12px 32px rgba(99,102,241,0.12)'; this.style.borderColor='#c7d2fe';"
                            onmouseout="this.style.transform=''; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.03)'; this.style.borderColor='#eef0f8';">
                            <div style="width:44px; height:44px; border-radius:12px; background:linear-gradient(135deg,#ede9fe,#ddd6fe); display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                                <i class="fa-solid fa-headset" style="color:#7c3aed; font-size:18px;"></i>
                            </div>
                            <div style="flex:1;">
                                <div style="font-size:13px; font-weight:700; color:#0f172a; margin-bottom:3px;">#SR-00<?php echo e($ticket->id); ?> — <?php echo e($ticket->title); ?></div>
                                <div style="font-size:11px; color:#64748b;"><?php echo e($ticket->created_at->diffForHumans()); ?></div>
                            </div>
                            <?php
                                $statusStyles = [
                                    'open' => 'background:#ede9fe; color:#5b21b6;',
                                    'in_progress' => 'background:#fef3c7; color:#92400e;',
                                    'resolved' => 'background:#d1fae5; color:#065f46;',
                                ];
                                $statusIcons = [
                                    'open' => 'fa-circle-dot',
                                    'in_progress' => 'fa-spinner',
                                    'resolved' => 'fa-circle-check',
                                ];
                            ?>
                            <span style="font-size:10px; font-weight:600; padding:4px 12px; border-radius:99px; <?php echo e($statusStyles[$ticket->status] ?? ''); ?> display:inline-flex; align-items:center; gap:4px;">
                                <i class="fa-solid <?php echo e($statusIcons[$ticket->status] ?? 'fa-circle'); ?>" style="font-size:8px;"></i>
                                <?php echo e(ucfirst(str_replace('_',' ',$ticket->status))); ?>

                            </span>
                            <i class="fa-solid fa-chevron-right" style="color:#94a3b8; font-size:11px;"></i>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php endif; ?><?php /**PATH /Users/wanli/Desktop/Final Year Project/helpdesk-system/resources/views/tickets/index.blade.php ENDPATH**/ ?>